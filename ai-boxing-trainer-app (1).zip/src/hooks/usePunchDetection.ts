import { useState, useRef, useCallback } from 'react';
import { PunchType, HandSide, Point } from '../types';

// Simplified punch detection using basic motion analysis
// This will be enhanced with MediaPipe when available

export interface PunchDetectionResult {
  type: PunchType;
  hand: HandSide;
  speed: number;
  direction: Point;
  power: number;
  timestamp: number;
}

export interface HandPosition {
  x: number;
  y: number;
  timestamp: number;
}

// Punch thresholds
const PUNCH_CONFIG = {
  jab: {
    minSpeed: 0.15, // normalized screen width per second
    maxAngle: 30, // degrees from horizontal
    requiredHand: 'left' as HandSide,
  },
  cross: {
    minSpeed: 0.15,
    maxAngle: 30,
    requiredHand: 'right' as HandSide,
  },
  hook: {
    minSpeed: 0.12,
    minAngle: 45,
    maxAngle: 135,
    requiredHand: 'both' as 'both',
  },
  uppercut: {
    minSpeed: 0.12,
    minVerticalSpeed: 0.08,
    requiredHand: 'both' as 'both',
  },
};

export const usePunchDetection = (
  videoRef: React.RefObject<HTMLVideoElement>,
  canvasRef: React.RefObject<HTMLCanvasElement>,
  onPunch?: (punch: PunchDetectionResult) => void,
  cameraMirror: boolean = true
) => {
  const [leftHand, setLeftHand] = useState<HandPosition | null>(null);
  const [rightHand, setRightHand] = useState<HandPosition | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Store previous positions for velocity calculation
  const prevLeftRef = useRef<HandPosition | null>(null);
  const prevRightRef = useRef<HandPosition | null>(null);
  
  // Cooldown to prevent multiple detections
  const cooldownRef = useRef<number>(0);
  
  // Video dimensions
  const [videoDimensions, setVideoDimensions] = useState({ width: 640, height: 480 });
  
  // Frame processing
  const processFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;
    
    // Set canvas dimensions
    if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      setVideoDimensions({ width: video.videoWidth || 640, height: video.videoHeight || 480 });
    }
    
    // Draw video frame (mirrored if needed)
    ctx.save();
    if (cameraMirror) {
      ctx.scale(-1, 1);
      ctx.translate(-canvas.width, 0);
    }
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    ctx.restore();
    
    // For demo purposes, we'll use a simplified hand tracking
    // In production, this would use MediaPipe
    detectHandsFromVideo(video, canvas.width, canvas.height);
    
  }, [videoRef, canvasRef, cameraMirror]);
  
  // Detect hands from video (simplified for demo)
  // In production, replace with MediaPipe
  const detectHandsFromVideo = (_video: HTMLVideoElement, _width: number, _height: number) => {
    const currentTime = Date.now();
    
    // This is a placeholder - in production, use MediaPipe
    // For now, we'll simulate hand detection based on motion
    
    // Simple color-based hand detection (for demo only)
    // In real app, use MediaPipe Hands
    
    // For the AI Boxing Trainer, we need proper hand tracking
    // Since MediaPipe loading is complex, we'll create a fallback
    
    // Check cooldown
    if (currentTime < cooldownRef.current) {
      return;
    }
    
    // Simulate hand positions based on mouse/touch for testing
    // In production, this would come from MediaPipe
    
    // For now, just update positions without detection
    // The actual punch detection will happen in the game logic
  };
  
  // Simplified punch detection based on hand movement
  const detectPunches = useCallback(() => {
    const currentTime = Date.now();
    
    if (currentTime < cooldownRef.current) return;
    
    const prevLeft = prevLeftRef.current;
    const prevRight = prevRightRef.current;
    
    // Detect left hand punch (jab)
    if (leftHand && prevLeft) {
      const timeDelta = (leftHand.timestamp - prevLeft.timestamp) / 1000;
      if (timeDelta > 0) {
        const dx = leftHand.x - prevLeft.x;
        const dy = leftHand.y - prevLeft.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const speed = distance / timeDelta;
        const direction = { x: dx / distance, y: dy / distance };
        
        // Normalize speed relative to screen size
        const normalizedSpeed = speed / videoDimensions.width;
        
        // Check for jab
        if (isJab(normalizedSpeed, direction)) {
          onPunch?.({
            type: 'jab',
            hand: 'left',
            speed: normalizedSpeed,
            direction,
            power: Math.min(100, normalizedSpeed * 100),
            timestamp: currentTime,
          });
          cooldownRef.current = currentTime + 300;
        }
        
        // Check for hook
        if (isHook(normalizedSpeed, direction)) {
          onPunch?.({
            type: 'hook',
            hand: 'left',
            speed: normalizedSpeed,
            direction,
            power: Math.min(100, normalizedSpeed * 100),
            timestamp: currentTime,
          });
          cooldownRef.current = currentTime + 300;
        }
        
        // Check for uppercut
        if (isUppercut(normalizedSpeed, direction)) {
          onPunch?.({
            type: 'uppercut',
            hand: 'left',
            speed: normalizedSpeed,
            direction,
            power: Math.min(100, normalizedSpeed * 100),
            timestamp: currentTime,
          });
          cooldownRef.current = currentTime + 300;
        }
      }
    }
    
    // Detect right hand punch (cross)
    if (rightHand && prevRight) {
      const timeDelta = (rightHand.timestamp - prevRight.timestamp) / 1000;
      if (timeDelta > 0) {
        const dx = rightHand.x - prevRight.x;
        const dy = rightHand.y - prevRight.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const speed = distance / timeDelta;
        const direction = { x: dx / distance, y: dy / distance };
        
        const normalizedSpeed = speed / videoDimensions.width;
        
        // Check for cross
        if (isCross(normalizedSpeed, direction)) {
          onPunch?.({
            type: 'cross',
            hand: 'right',
            speed: normalizedSpeed,
            direction,
            power: Math.min(100, normalizedSpeed * 100),
            timestamp: currentTime,
          });
          cooldownRef.current = currentTime + 300;
        }
        
        // Check for hook
        if (isHook(normalizedSpeed, direction)) {
          onPunch?.({
            type: 'hook',
            hand: 'right',
            speed: normalizedSpeed,
            direction,
            power: Math.min(100, normalizedSpeed * 100),
            timestamp: currentTime,
          });
          cooldownRef.current = currentTime + 300;
        }
        
        // Check for uppercut
        if (isUppercut(normalizedSpeed, direction)) {
          onPunch?.({
            type: 'uppercut',
            hand: 'right',
            speed: normalizedSpeed,
            direction,
            power: Math.min(100, normalizedSpeed * 100),
            timestamp: currentTime,
          });
          cooldownRef.current = currentTime + 300;
        }
      }
    }
    
    // Update previous positions
    if (leftHand) prevLeftRef.current = leftHand;
    if (rightHand) prevRightRef.current = rightHand;
    
  }, [leftHand, rightHand, onPunch, videoDimensions]);
  
  // Punch type detectors
  const isJab = (speed: number, direction: Point): boolean => {
    const config = PUNCH_CONFIG.jab;
    if (speed < config.minSpeed) return false;
    
    const angle = Math.abs(Math.atan2(direction.y, direction.x) * (180 / Math.PI));
    return angle <= config.maxAngle && direction.x < 0; // Moving left (for jab)
  };
  
  const isCross = (speed: number, direction: Point): boolean => {
    const config = PUNCH_CONFIG.cross;
    if (speed < config.minSpeed) return false;
    
    const angle = Math.abs(Math.atan2(direction.y, direction.x) * (180 / Math.PI));
    return angle <= config.maxAngle && direction.x > 0; // Moving right (for cross)
  };
  
  const isHook = (speed: number, direction: Point): boolean => {
    const config = PUNCH_CONFIG.hook;
    if (speed < config.minSpeed) return false;
    
    const angle = Math.abs(Math.atan2(direction.y, direction.x) * (180 / Math.PI));
    return angle >= (config.minAngle as number) && angle <= (config.maxAngle as number);
  };
  
  const isUppercut = (speed: number, direction: Point): boolean => {
    const config = PUNCH_CONFIG.uppercut;
    if (speed < config.minSpeed) return false;
    
    const verticalSpeed = Math.abs(direction.y) * speed;
    return verticalSpeed >= (config.minVerticalSpeed as number) && direction.y < 0;
  };
  
  // Start camera
  const startCamera = useCallback(async () => {
    try {
      if (!videoRef.current) return;
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
        audio: false,
      });
      
      videoRef.current.srcObject = stream;
      videoRef.current.play();
      setIsTracking(true);
      setError(null);
      
      // Start frame processing loop
      const processLoop = () => {
        if (!isTracking) return;
        processFrame();
        detectPunches();
        requestAnimationFrame(processLoop);
      };
      
      processLoop();
      
    } catch (err) {
      setError('Cannot access camera. Please enable camera permissions.');
      console.error('Camera error:', err);
    }
  }, [videoRef, processFrame, detectPunches, isTracking]);
  
  // Stop camera
  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsTracking(false);
  }, [videoRef]);
  
  // Update hand positions (called from MediaPipe or other tracking)
  const updateHandPosition = useCallback((hand: HandSide, x: number, y: number) => {
    const position = { x, y, timestamp: Date.now() };
    
    if (hand === 'left') {
      setLeftHand(position);
    } else {
      setRightHand(position);
    }
  }, []);
  
  // Clear hand positions
  const clearHands = useCallback(() => {
    setLeftHand(null);
    setRightHand(null);
    prevLeftRef.current = null;
    prevRightRef.current = null;
  }, []);
  
  return {
    leftHand,
    rightHand,
    isTracking,
    error,
    videoDimensions,
    startCamera,
    stopCamera,
    updateHandPosition,
    clearHands,
    processFrame,
  };
};

export default usePunchDetection;
