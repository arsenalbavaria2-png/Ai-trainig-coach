// Core types for the AI Boxing Trainer app

export type Language = 'en' | 'ru' | 'uz';

export type PunchType = 'jab' | 'cross' | 'hook' | 'uppercut';

export type HandSide = 'left' | 'right';

export interface Point {
  x: number;
  y: number;
  z?: number;
}

export interface PunchData {
  type: PunchType;
  hand: HandSide;
  speed: number; // pixels per frame
  direction: Point; // normalized direction vector
  power: number; // 0-100
  accuracy: number; // 0-100
  timestamp: number;
  hitTarget: boolean;
  targetId?: string;
}

export interface Target {
  id: string;
  position: Point;
  size: number;
  type: PunchType;
  hand: HandSide;
  active: boolean;
  hit: boolean;
  spawnTime: number;
  expiryTime: number;
  angle?: number; // for angled targets
}

export interface ComboPattern {
  punches: { type: PunchType; hand: HandSide }[];
  currentIndex: number;
  completed: boolean;
}

export interface WorkoutStats {
  totalPunches: number;
  accuratePunches: number;
  accuracy: number;
  calories: number;
  duration: number; // in seconds
  combosCompleted: number;
  maxCombo: number;
  punchesByType: Record<PunchType, number>;
}

export interface LevelData {
  id: number;
  name: string;
  description: string;
  difficulty: number; // 1-10
  mittSpeed: number; // time between mitts in ms
  hitWindow: number; // time window for hitting in ms
  comboPattern: PunchType[];
  techniques: PunchType[];
  stars: number; // 0-3, earned by user
  unlocked: boolean;
  bestScore: number;
}

export interface UserProfile {
  id: string;
  name: string;
  language: Language;
  totalWorkouts: number;
  totalPunches: number;
  totalCalories: number;
  currentStreak: number;
  longestStreak: number;
  lastWorkoutDate: string;
  levelsCompleted: Set<number>;
  settings: {
    soundEnabled: boolean;
    cameraMirror: boolean;
    difficultyOffset: number; // -2 to +2
  };
}

export interface AppState {
  // Camera & Tracking
  cameraActive: boolean;
  trackingActive: boolean;
  
  // Game State
  currentLevel: number;
  levels: LevelData[];
  currentTargets: Target[];
  currentCombo: ComboPattern | null;
  score: number;
  comboCounter: number;
  timeRemaining: number;
  workoutInProgress: boolean;
  paused: boolean;
  
  // Stats
  workoutStats: WorkoutStats;
  sessionPunches: PunchData[];
  
  // User
  user: UserProfile | null;
  
  // UI
  language: Language;
  showSettings: boolean;
  showSummary: boolean;
  showInstruction: boolean;
  currentInstruction: PunchType | null;
  
  // Health tips
  currentTip: string;
}

export interface Landmark {
  x: number;
  y: number;
  z: number;
  visibility: number;
}

export interface HandLandmarks {
  wrist: Landmark;
  thumbCmc: Landmark;
  thumbMcp: Landmark;
  thumbIp: Landmark;
  thumbTip: Landmark;
  indexFingerMcp: Landmark;
  indexFingerPip: Landmark;
  indexFingerDip: Landmark;
  indexFingerTip: Landmark;
  middleFingerMcp: Landmark;
  middleFingerPip: Landmark;
  middleFingerDip: Landmark;
  middleFingerTip: Landmark;
  ringFingerMcp: Landmark;
  ringFingerPip: Landmark;
  ringFingerDip: Landmark;
  ringFingerTip: Landmark;
  pinkyMcp: Landmark;
  pinkyPip: Landmark;
  pinkyDip: Landmark;
  pinkyTip: Landmark;
}

export interface PoseLandmarks {
  nose: Landmark;
  leftEyeInner: Landmark;
  leftEye: Landmark;
  leftEyeOuter: Landmark;
  rightEyeInner: Landmark;
  rightEye: Landmark;
  rightEyeOuter: Landmark;
  leftEar: Landmark;
  rightEar: Landmark;
  mouthLeft: Landmark;
  mouthRight: Landmark;
  leftShoulder: Landmark;
  rightShoulder: Landmark;
  leftElbow: Landmark;
  rightElbow: Landmark;
  leftWrist: Landmark;
  rightWrist: Landmark;
  leftPinky: Landmark;
  rightPinky: Landmark;
  leftIndex: Landmark;
  rightIndex: Landmark;
  leftThumb: Landmark;
  rightThumb: Landmark;
  leftHip: Landmark;
  rightHip: Landmark;
  leftKnee: Landmark;
  rightKnee: Landmark;
  leftAnkle: Landmark;
  rightAnkle: Landmark;
  leftHeel: Landmark;
  rightHeel: Landmark;
  leftFootIndex: Landmark;
  rightFootIndex: Landmark;
}

export interface DetectionResult {
  leftHand: HandLandmarks | null;
  rightHand: HandLandmarks | null;
  pose: PoseLandmarks | null;
  timestamp: number;
}
